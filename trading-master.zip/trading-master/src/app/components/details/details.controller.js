(function(angular) {
  'use strict';
  angular.module('treading')
  .controller('DetailsController',DetailsController);

  /** @ngInject */
  function DetailsController(DetailsService, $state) {
    var vm = this;
    
    vm.details = DetailsService.getCompanyInfo($state.params.id);


  }
})(angular);