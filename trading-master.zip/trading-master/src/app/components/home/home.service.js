(function(){
  'use strict';
  angular
    .module('treading')
    .factory('HomeService', HomeService);

  function HomeService(){

    var companyList = [
      { 
      id: 1,
          company: 'Aricent Technologies',
          buy_price: 92,
          cell_price: 100
      },
      { 
      id: 2,
          company: 'Axles India Ltd',
          buy_price: 82,
          cell_price: 87
      },
      { 
      id: 3,
          company: 'Bharti Tele',
          buy_price: 75,
          cell_price: 85
      },
      { 
      id: 4,
          company: 'Capacite Structures Ltd',
          buy_price: 1050,
          cell_price: 1150
      },
      { 
      id: 5,
          company: 'Carrier Airconditioning & Refrig Ltd',
          buy_price: 160,
          cell_price: 175
      },
      {
      id: 6,
          company: 'Catholic Syrian Bank',
          buy_price: 170,
          cell_price: 175
      },
      {
      id: 7,
          company: 'Essar Steel Limited',
          buy_price: 40,
          cell_price: 42
      },
      {
      id: 8,
          company: 'FINO PayTech Limited',
          buy_price: 116,
          cell_price: 120
      },
      {
      id: 9,
          company: 'Frick India Ltd',
          buy_price: 2400,
          cell_price: 2550
      },
        { 
      id: 10,
          company: 'Galaxy Surfactants Ltd',
          buy_price: 620,
          cell_price: 0
      },
      {
      id: 11,
          company: 'HDB Financial Services Ltd',
          buy_price: 640,
          cell_price: 680
      },
      {
      id: 12,
          company: 'Hero Fincorp',
          buy_price: 1300,
          cell_price: 1360
      },
      {
      id: 13,
          company: 'Indian Wood Products Ltd',
          buy_price: 360,
          cell_price: 0
      },
      {
      id: 14,
          company: 'Indofil Industries Ltd',
          buy_price: 1050,
          cell_price: 1140
      },
      {
      id: 15,
          company: 'Kurlon Ltd',
          buy_price: 385,
          cell_price: 425
      },
      {
      id: 16,
          company: 'Metropolitan Stock Exchange',
          buy_price: 2,
          cell_price: 2
      },
      {
      id: 17,
          company: 'Mideast Integrated Steel',
          buy_price: 40,
          cell_price: 50
      },
      {
      id: 18,
          company: 'Modern Insulator',
          buy_price: 85,
          cell_price: 95
      },
      {
      id: 19,
          company: 'MSTC Ltd (Metal Scrap Trade Cor)',
          buy_price: 440,
          cell_price: 0
      },
      {
      id: 20,
          company: 'National Plywood Industries Ltd.',
          buy_price: 25,
          cell_price: 0
      },
      {
      id: 21,
          company: 'National Stock Exchange',
          buy_price: 870,
          cell_price: 0
      },
      {
      id: 22,
          company: 'Otis Elevator Company (I) Ltd',
          buy_price: 2300,
          cell_price: 2400
      },
      {
      id: 23,
          company: 'Philips Electronics India Ltd',
          buy_price: 460,
          cell_price: 490
      },
      {
      id: 24,
          company: 'Resins & Plastics Ltd',
          buy_price: 180,
          cell_price: 195
      },
      {
      id: 25,
          company: 'SMC GLOBAL SECURITIES LIMITED',
          buy_price: 110,
          cell_price: 125
      },
      {
      id: 26,
          company: 'Suryoday Small Finance Bank Limited',
          buy_price: 220,
          cell_price: 0
      },
      {
      id: 27,
          company: 'Syngenta India Ltd',
          buy_price: 1000,
          cell_price: 1050
      },
      {
      id: 28,
          company: 'Tamilnad Mercantile Bank',
          buy_price: 440,
          cell_price: 455
      },
      {
      id: 29,
          company: 'Tata Technologies',
          buy_price: 2100,
          cell_price: 2300
      },
      {
      id: 30,
          company: 'UTI AMC (Mutual Fund)',
          buy_price: 700,
          cell_price: 740
      },
      {
      id: 31,
          company: 'Utkarsh Mirco Finance',
          buy_price: 205,
          cell_price: 0
      },
      {
      id: 32,
          company: 'Utkarsh Small Finance Bank Limited',
          buy_price: 40,
          cell_price: 0
      }
    ];
    

    return{
      companyList: companyList
    }

}

})();
