(function(angular) {
  'use strict';
  angular.module('treading')
  .controller('HomeController',HomeController);

  /** @ngInject */
  function HomeController(HomeService, $state) {
    var vm = this;

    vm.list = HomeService.companyList;

    vm.goToDetails = function(id){
      $state.go('home.details',{id: id});
    }

    var text = ["Easy", "Transparent", "Fast"];
    var counter = 0;
    var elem = document.getElementById("change-text");
    setInterval(change, 2000);
    
    function change() {
      elem.innerHTML = text[counter];
      counter++;
      if (counter >= text.length) {
        counter = 0;
      }
    }

  }
})(angular);