(function(angular) {
  'use strict';
  angular.module('treading')
  .controller('CompanyController',CompanyController);

  /** @ngInject */
  function CompanyController(CompanyService, $log) {
    var vm = this;
     
    CompanyService.getDetails()
    .then(function (data) {
      vm.data = data;
      addImage(vm.data);
    }, function () {
      $log.log("Failed!");
    });

    function addImage(data){
      for(var i in data){
        if(data[i].logo == undefined){
          data[i].logo = '/assets/images/nf.jpg'
        }
      }
    }


  }
})(angular);
