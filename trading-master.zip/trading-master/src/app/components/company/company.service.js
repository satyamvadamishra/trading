(function(){
  'use strict';
  angular
    .module('treading')
    .factory('CompanyService', CompanyService)

  function CompanyService($http, $q){

    var getDetails = function(){
      var deferred = $q.defer();
      $http({
        method: 'GET',
        url: 'https://beta.aetlo.com/api/v1/users/sell_requests'
      })
      .success(function (data, status, headers, config) {
        deferred.resolve(data, status, headers, config);
      })
      .error(function (data, status, header, config) {
        deferred.reject(data, status, header, config);
      });
      return deferred.promise;
    }


    return{
      getDetails: getDetails
    }

  }


})();
