(function(angular) {
  'use strict';
  angular.module('treading')
  .controller('SignupController',SignupController);

  /** @ngInject */
  function SignupController(SignupService, $log) {
    var vm = this;
    
    vm.signup = {};

    vm.signupForm = function(){
      SignupService.PostSignupForm(vm.signup)
      .then(function(data){
        data = data
        vm.signup = {};
      },function(){
        $log.log("Failed!");
    });
    }


  }
})(angular);