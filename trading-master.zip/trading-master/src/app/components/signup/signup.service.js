(function(){
  'use strict';
  angular
    .module('treading')
    .factory('SignupService', SignupService)

  function SignupService($http, $q){

    var PostSignupForm = function(data){
      var deferred = $q.defer();
      $http({
        method: 'POST',
        url: 'http://beta.aetlo.com/api/v1/users/signup',
        data: data
      })
      .success(function (data, status, headers, config) {
        deferred.resolve(data, status, headers, config);
      })
      .error(function (data, status, header, config) {
        deferred.reject(data, status, header, config);
      });
      return deferred.promise;
    }


    return{
      PostSignupForm: PostSignupForm
    }

  }


})();