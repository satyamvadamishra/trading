(function(angular) {
  'use strict';
  angular.module('treading')
  .controller('LoginController',LoginController);

  /** @ngInject */
  function LoginController() {
 
     


  }
})(angular);