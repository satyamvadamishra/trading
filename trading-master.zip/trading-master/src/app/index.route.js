(function() {
  'use strict';

  angular
    .module('treading')
    .config(routerConfig);

  /** @ngInject */
  function routerConfig($stateProvider, $urlRouterProvider, $locationProvider) {
    $stateProvider
    .state('home', {
      url: '/',
      views: {
        '@': {
          templateUrl: 'app/main/main.html'
        },
        'main-content@home': {
          templateUrl: 'app/components/home/home.html',
          controller:   'HomeController',
          controllerAs: 'HomeCtrl'
        },
        'header@home': {
          templateUrl: 'app/components/header/header.html'
        },
        'footer@home': {
          templateUrl: 'app/components/footer/footer.html'
        }
      }
    })
    .state('home.details', {
      url: '^/details/{id}',
      views: {
        "main-content@home": {
          templateUrl: 'app/components/details/details.html',
          controller: 'DetailsController',
          controllerAs: 'DetailsCtrl'
        }
      }
    })
    .state('home.login', {
      url: '^/login',
      views: {
        "main-content@home": {
          templateUrl: 'app/components/login/login.html',
          controller: 'LoginController',
          controllerAs: 'LoginCtrl'
        }
      }
    })
    .state('home.signup', {
      url: '^/signup',
      views: {
        "main-content@home": {
          templateUrl: 'app/components/signup/signup.html',
          controller: 'SignupController',
          controllerAs: 'SignupCtrl'
        }
      }
    })
    .state('home.company', {
      url: '^/company',
      views: {
        "main-content@home": {
          templateUrl: 'app/components/company/company.html',
          controller: 'CompanyController',
          controllerAs: 'CompCtrl'
        }
      }
    })

    $locationProvider.html5Mode({
      enabled: true,
      requireBase: false
    });

    $urlRouterProvider.otherwise('/');
  }

})();
